'use strict';

const command = require('../lib');

describe('@moderate-cli/command', () => {
    it('needs tests');
});
