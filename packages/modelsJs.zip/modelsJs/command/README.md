# `@moderate-cli/index`

> TODO: description

## Usage

```
const index = require('@moderate-cli/index');

// TODO: DEMONSTRATE API
```
